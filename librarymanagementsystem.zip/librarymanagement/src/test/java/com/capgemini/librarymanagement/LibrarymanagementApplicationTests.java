package com.capgemini.librarymanagementplp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LibrarymanagementPlpApplicationTests {

	@Test
	void contextLoads() {
	}

}
