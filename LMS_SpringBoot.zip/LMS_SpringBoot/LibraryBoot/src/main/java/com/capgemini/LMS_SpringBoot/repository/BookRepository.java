package com.capgemini.libraryboot.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.capgemini.libraryboot.model.Book;

public interface BookRepository extends JpaRepository<Book, Integer>{

}
