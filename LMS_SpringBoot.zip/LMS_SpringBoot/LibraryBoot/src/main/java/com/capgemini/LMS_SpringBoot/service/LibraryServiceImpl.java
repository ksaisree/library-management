package com.capgemini.libraryboot.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.libraryboot.model.Book;
import com.capgemini.libraryboot.repository.BookRepository;

@Service
public class LibraryServiceImpl {
	
	@Autowired
	private BookRepository bookRepo;
	
	public void deleteBook(Integer bookId) {
		bookRepo.deleteById(bookId);
	}
	
	public Book searchBook(Integer bookId) {
		Optional<Book> book=bookRepo.findById(bookId);
		Book b = book.get();
		return b;
	}
	
	public Book updateBook(int bId,String bName,String bAuthor, String bPublisher) {
		Book book=searchBook(bId);
		book.setBookName(bName);
		book.setAuthor(bAuthor);
		book.setPublisher(bPublisher);
		bookRepo.save(book);
		return book;
	}
}
