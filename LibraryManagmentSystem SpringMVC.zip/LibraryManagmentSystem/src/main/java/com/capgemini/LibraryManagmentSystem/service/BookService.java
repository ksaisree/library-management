package com.capgemini.libsmvc.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.capgemini.libsmvc.beans.Book;

@Service
public interface BookService {
	public Book addBook(Book book);
	public boolean updateBook(Book bookId);
	public boolean deleteBook(int bookId);
	public List<Book> getAllbook();
	public Book SearchBook(int bookId);
}
