package com.capgemini.libsmvc.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.capgemini.libsmvc.beans.Book;

@Repository
public class BookDaoImpl implements BookDao {

	private static EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("smvc");

	public Book addBook(Book book) {
		try {
			EntityManager entityManager = entityManagerFactory.createEntityManager();
			EntityTransaction entityTransaction = entityManager.getTransaction();
			entityTransaction.begin();
			entityManager.persist(book);
			entityTransaction.commit();
			entityManager.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return book;
	}

	public boolean updateBook(Book bookId) {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		EntityTransaction transaction = entityManager.getTransaction();
		boolean isadded = false;
		try {
			transaction.begin();
			entityManager.merge(bookId);
			transaction.commit();
			isadded = true;
		} catch (Exception e) {
			transaction.rollback();
			return isadded;
		}
		entityManager.close();
		return isadded;
	}

	public boolean deleteBook(int bookId) {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		EntityTransaction transaction = entityManager.getTransaction();
		try {
			Book book = null;
			book = entityManager.find(Book.class, bookId);
			if (book == null) {
				return false;
			} else {
				transaction.begin();
				entityManager.remove(book);
				transaction.commit();
			}
		} catch (Exception e) {
			transaction.rollback();
			return false;
		}
		entityManager.close();
		return true;
	}

	public List<Book> getAllbook() {
		List<Book> books = null;
		try {
			EntityManager entityManager = entityManagerFactory.createEntityManager();
			entityManager.getTransaction().begin();
			TypedQuery<Book> query = entityManager.createQuery("SELECT b FROM Book b", Book.class);
			books = query.getResultList();
			entityManager.getTransaction().commit();
			entityManager.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return books;
	}

	public Book SearchBook(int bookId) {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		Book book = null;
		book = entityManager.find(Book.class, bookId);
		if (book != null) {
			return book;
		} else {
		}
		entityManager.close();
		return book;
	}
}