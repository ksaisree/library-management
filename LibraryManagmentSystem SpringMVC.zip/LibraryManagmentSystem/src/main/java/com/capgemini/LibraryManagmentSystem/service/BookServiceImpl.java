package com.capgemini.libsmvc.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.libsmvc.beans.Book;
import com.capgemini.libsmvc.dao.BookDao;
import com.capgemini.libsmvc.dao.BookDaoImpl;

@Service
public class BookServiceImpl implements BookService {
	BookDao bookdao = new BookDaoImpl();

	@Transactional
	public Book addBook(Book book) {
		return bookdao.addBook(book);
	}

	@Transactional
	public boolean updateBook(Book bookId) {
		return bookdao.updateBook(bookId);
	}

	@Transactional
	public boolean deleteBook(int bookId) {
		return bookdao.deleteBook(bookId);
	}

	@Transactional
	public List<Book> getAllbook() {
		return bookdao.getAllbook();
	}

	@Transactional
	public Book SearchBook(int bookId) {
		return bookdao.SearchBook(bookId);
	}

}
