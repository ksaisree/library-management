package com.capgemini.libsmvc.dao;

import java.util.List;

import com.capgemini.libsmvc.beans.Book;

public interface BookDao {
	public Book addBook(Book book);
	public boolean updateBook(Book bookId);
	public boolean deleteBook(int bookId);
	public List<Book> getAllbook();
	public Book SearchBook(int bookId);
	
}
